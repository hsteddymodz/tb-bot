<?php

 if($type == 'private') {
 
    apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => "*꧁꧂꧁꧂
꧁꧂BIN꧁꧂
꧁꧂TEL꧁꧂
 ꧁꧂CEP꧁꧂
꧁꧂CNPJ꧁꧂
 ꧁꧂PLACA꧁꧂
꧁꧂CPF1꧁꧂
꧁꧂CPF2꧁꧂
 ꧁꧂IP꧁꧂
꧁꧂NOME꧁꧂
꧁꧂PARENTES꧁꧂
꧁꧂VIZINHOS꧁꧂
꧁꧂EMAIL꧁꧂
꧁꧂꧁꧂꧁꧂

♠️ 𝖭𝖮𝖵𝖮𝖲 𝖬𝖮́𝖣𝖴𝖫𝖮𝖲 𝖤𝖬 𝖡𝖱𝖤𝖵𝖤 ♠️

꧁꧂ 𝗧𝗔𝗕𝗘𝗟𝗔 𝗗𝗘 𝗣𝗥𝗘𝗖̧𝗢𝗦 ꧁꧂

✅  07 DIAS 20 R$
✅  15 DIAS 35 R$
✅  30 DIAS 50 R$ 
✅  60 DIAS 85 R$

♣️ 𝘊𝘖𝘕𝘚𝘜𝘓𝘛𝘈𝘚 𝘐𝘓𝘐𝘔𝘐𝘛𝘈𝘋𝘈𝘚 ♣️

💎  𝙏𝘼𝘽𝙀𝙇𝘼 𝘿𝙀 𝙋𝙍𝙀𝘾̧𝙊𝙎 𝙋𝘼𝙍𝘼 𝙂𝙍𝙐𝙋𝙊 𝙑𝙄𝙋 💎

✅ 7 DIAS 25 R$ 
✅ 15 DIAS 45 R$ 
✅ 1 MES 80 R$

💰 𝙁𝙊𝙍𝙈𝘼𝙎 𝘿𝙀 𝙋𝘼𝙂𝘼𝙈𝙀𝙉𝙏𝙊 💰

----------------------------------------------
💰𝗣𝗜𝗫
----------------------------------------------

• 𝗖𝗔𝗡𝗔𝗟 𝗗𝗘 𝗥𝗘𝗙𝗦 
@mdzup

• 𝗚𝗥𝗨𝗣𝗢 𝗢𝗙𝗖 
@mdzdonates

• 𝗗𝗢𝗡𝗢 𝗗𝗢 𝗕𝗢𝗧
@gringomdz

👺 𝘔𝘌𝘓𝘏𝘖𝘙 𝘚𝘜𝘗𝘖𝘙𝘛𝘌 𝘋𝘖 𝘛𝘌𝘓𝘌𝘎𝘙𝘈𝘔 👺

🚨 𝘊𝘏𝘈𝘔𝘖𝘜 𝘗𝘝 𝘌 𝘍𝘐𝘊𝘖𝘜 𝘌𝘕𝘙𝘖𝘓𝘈𝘕𝘋𝘖 = 𝘚𝘗𝘈𝘔 🚨

 ❌ 𝙎𝙊́ 𝘾𝙃𝘼𝙈𝘼 𝙎𝙀 𝙌𝙐𝙄𝙎𝙀𝙍 𝘾𝙊𝙈𝙋𝙍𝘼𝙍 ❌*", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                                                                          
                                                      //linha 1
                                                     array(
                                                         array('text'=>'☑️ Comprar Acesso VIP ☑️','url'=>'https://t.me/gringomdz')
                                                      )                                                          
                                            )
                                    )));

}else{
                
    apiRequest("editMessageText", array('chat_id' => $chat_id, 'message_id' => $message_id, "parse_mode" => "Markdown", "text" => "*꧁꧂꧁꧂
꧁꧂BIN꧁꧂
꧁꧂TEL꧁꧂
 ꧁꧂CEP꧁꧂
꧁꧂CNPJ꧁꧂
 ꧁꧂PLACA꧁꧂
꧁꧂CPF1꧁꧂
꧁꧂CPF2꧁꧂
 ꧁꧂IP꧁꧂
꧁꧂NOME꧁꧂
꧁꧂PARENTES꧁꧂
꧁꧂VIZINHOS꧁꧂
꧁꧂EMAIL꧁꧂
꧁꧂꧁꧂꧁꧂

♠️ 𝖭𝖮𝖵𝖮𝖲 𝖬𝖮́𝖣𝖴𝖫𝖮𝖲 𝖤𝖬 𝖡𝖱𝖤𝖵𝖤 ♠️

꧁꧂ 𝗧𝗔𝗕𝗘𝗟𝗔 𝗗𝗘 𝗣𝗥𝗘𝗖̧𝗢𝗦 ꧁꧂

✅  07 DIAS 20 R$
✅  15 DIAS 35 R$
✅  30 DIAS 50 R$ 
✅  60 DIAS 85 R$

♣️ 𝘊𝘖𝘕𝘚𝘜𝘓𝘛𝘈𝘚 𝘐𝘓𝘐𝘔𝘐𝘛𝘈𝘋𝘈𝘚 ♣️

💎  𝙏𝘼𝘽𝙀𝙇𝘼 𝘿𝙀 𝙋𝙍𝙀𝘾̧𝙊𝙎 𝙋𝘼𝙍𝘼 𝙂𝙍𝙐𝙋𝙊 𝙑𝙄𝙋 💎

✅ 7 DIAS 25 R$ 
✅ 15 DIAS 45 R$ 
✅ 1 MES 80 R$

💰 𝙁𝙊𝙍𝙈𝘼𝙎 𝘿𝙀 𝙋𝘼𝙂𝘼𝙈𝙀𝙉𝙏𝙊 💰

----------------------------------------------
💰𝗣𝗜𝗫
----------------------------------------------

• 𝗖𝗔𝗡𝗔𝗟 𝗗𝗘 𝗥𝗘𝗙𝗦 
@mdzup

• 𝗚𝗥𝗨𝗣𝗢 𝗢𝗙𝗖 
@mdzdonates

• 𝗗𝗢𝗡𝗢 𝗗𝗢 𝗕𝗢𝗧
@gringomdz

👺 𝘔𝘌𝘓𝘏𝘖𝘙 𝘚𝘜𝘗𝘖𝘙𝘛𝘌 𝘋𝘖 𝘛𝘌𝘓𝘌𝘎𝘙𝘈𝘔 👺

🚨 𝘊𝘏𝘈𝘔𝘖𝘜 𝘗𝘝 𝘌 𝘍𝘐𝘊𝘖𝘜 𝘌𝘕𝘙𝘖𝘓𝘈𝘕𝘋𝘖 = 𝘚𝘗𝘈𝘔 🚨

 ❌ 𝙎𝙊́ 𝘾𝙃𝘼𝙈𝘼 𝙎𝙀 𝙌𝙐𝙄𝙎𝙀𝙍 𝘾𝙊𝙈𝙋𝙍𝘼𝙍 ❌*", "reply_to_message_id" => $message_id,
'reply_markup' => array('inline_keyboard' => array(                                                                                                                                                                                                          
                                                      //linha 1
                                                     array(
                                                         array('text'=>'☑️ Comprar Acesso VIP ☑️','url'=>'https://t.me/gringomdz')
                                                      )                                                          
                                            )
                                    )));

} 

?>